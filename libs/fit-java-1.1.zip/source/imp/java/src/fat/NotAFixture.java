package fat;

public class NotAFixture {
}
