package fat;

import fit.Fixture;

public class ExampleFixture extends Fixture {

}
